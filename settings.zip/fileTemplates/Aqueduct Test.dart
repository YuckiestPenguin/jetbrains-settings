import 'harness/app.dart';

Future main() async {
  final harness = Harness()..install();

  test("Example", () async {
    final response = await harness.agent.get("/path");
    expectResponse(response, 200);
  });
}
