#set( $CAMEL_NAME = ${StringUtils.removeAndHump(${NAME})})
import 'package:aqueduct/aqueduct.dart';
import 'package:${PROJECT_NAME}/${PROJECT_NAME}.dart';

class ${CAMEL_NAME} extends ResourceController {
  
}